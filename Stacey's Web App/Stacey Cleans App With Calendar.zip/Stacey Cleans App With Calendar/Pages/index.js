var Name = document.getElementByID("Name");
var Email = document.getElementByID("Email");

function deleteClient(){
	var firebaseRef = firebase.database().ref();
	var nameText = Name.value;
	firebaseRef.child("Text").set(nameText);
}