<?php
$client = new MongoDB\Client(
'mongodb://Dylan:stocktonsucks@mycluster0-shard-00-00.mongodb.net:27017,mycluster0-shard-00-01.mongodb.net:27017,mycluster0-shard-00-02.mongodb.net:27017/admin?ssl=true&replicaSet=Mycluster0-shard-0&authSource=admin&serverSelectionTryOnce=false&serverSelectionTimeoutMS=15000"');

$db = $client->test;
$collection = $db->user;

if($_POST)
{
$insert = array(
	'Name'=> $_POST['Name'],
	'Email'=> $_POST['Email'],
	'Phone'=> $_POST['Phone'],
	'Address'=> $_POST['Address'],
	'Period'=> $_POST['Period'],
	'Price'=> $_POST['Price']
);

if($collection->insert($insert))
{
	echo "data is inserted";
}
else {
	echo "some issues";
}
}
else {
	echo "no data to store";
}
?>